public class MyClass {
}
