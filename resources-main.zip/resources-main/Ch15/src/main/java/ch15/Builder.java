package ch15;

public interface Builder<T> {
    T build();
}
