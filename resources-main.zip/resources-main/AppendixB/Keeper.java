public class Keeper {
    private boolean trainee;

    public boolean isTrainee() {
        return trainee;
    }
}
