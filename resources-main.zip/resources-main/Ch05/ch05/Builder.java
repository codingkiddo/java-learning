package ch05;

public interface Builder<T> {
    T build();
}
