module wgjd.png {
  exports wgjd.png;

  requires jdk.incubator.foreign;
}
