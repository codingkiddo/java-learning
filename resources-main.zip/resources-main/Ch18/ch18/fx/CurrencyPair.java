package ch18.fx;

public enum CurrencyPair {
    GBPUSD, GBPEUR, USDEUR
}
