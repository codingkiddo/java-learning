package ch18.fx;

public enum Side {
    BUY, SELL
}
