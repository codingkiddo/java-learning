package ch18.fx;

enum OrderType {
    MARKET,
    LIMIT
}
