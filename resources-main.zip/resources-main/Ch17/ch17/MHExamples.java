package ch17;

import java.lang.invoke.MethodType;

public class MHExamples {
    public static void main(String[] args) {
        var mt = MethodType.methodType(String.class);
    }



}
