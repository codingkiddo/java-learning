java -cp /Users/jasonclark/source/well-grounded/code/Ch10/maven-modules/non-app/target/nonapp-2.0.jar:../mod-lib/target/modlib-2.0.jar com.wellgrounded.nonapp.Main
