package com.wellgrounded.modlib.visible;

public class UseThis {
  public static String getMessage() {
    return "Modules for fun and profit";
  }
}
