package com.wellgrounded.modlib.hidden;

public class CantTouchThis {
  public static String getMessage() {
    return "Hammertime";
  }
}
