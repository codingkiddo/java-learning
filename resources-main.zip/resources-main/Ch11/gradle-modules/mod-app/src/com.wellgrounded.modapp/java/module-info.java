module com.wellgrounded.modapp {
    requires com.wellgrounded.modlib;
}
