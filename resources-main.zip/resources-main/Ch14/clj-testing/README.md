To run tests using the cognitect-labs test-runner:

```
bin/cognitect-test
```

To run tests with kaocha:

```
bin/kaocha
```
