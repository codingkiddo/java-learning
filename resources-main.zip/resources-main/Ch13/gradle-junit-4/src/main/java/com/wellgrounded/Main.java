package com.wellgrounded;

public class Main {
  public static String getMessage() {
    return "Gradle for fun and profit";
  }

  public static void main(String[] args) {
    System.out.println(getMessage());
  }
}
