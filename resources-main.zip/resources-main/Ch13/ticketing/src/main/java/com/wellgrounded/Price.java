package com.wellgrounded;

import java.math.BigDecimal;

public interface Price {
    BigDecimal getInitialPrice();
}