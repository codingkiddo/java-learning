# Small app to show Kotlin-Java interoperability features

`./gradlew build` will generate the class files for inspection under `./build`
directory.

To run the sample at the command-line, use `./gradlew run`
