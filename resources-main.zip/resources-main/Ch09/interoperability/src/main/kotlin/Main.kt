package com.wellgrounded.kotlin

fun shout() {
  println("No classes in sight!")
}
