module wgjd.sitecheck {
  requires java.net.http;

  exports wgjd.sitecheck;
  exports wgjd.sitecheck.concurrent;
}
