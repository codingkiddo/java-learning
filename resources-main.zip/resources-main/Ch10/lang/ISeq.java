package lang;

public interface ISeq {
    Object first();
    ISeq rest();
}
