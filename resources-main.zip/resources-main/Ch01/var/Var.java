package var;

public class Var {

    public static Var var() {
        return new Var();
    }

    public static Var var(Var var) {
        return new Var();
    }

}
