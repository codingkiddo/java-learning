  case class TemperatureAlarm(temp : Double)
