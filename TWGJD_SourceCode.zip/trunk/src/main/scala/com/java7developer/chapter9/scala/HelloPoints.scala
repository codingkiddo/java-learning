  object HelloPoints {
    def main(args : Array[String]) {
		var cp = CasePoint(2, 3);
		var cp2 = CasePoint(5, 7);
		
		println(cp)
		println(cp2)
		println(cp * 2)
		println(cp + cp2)
    }
  }

