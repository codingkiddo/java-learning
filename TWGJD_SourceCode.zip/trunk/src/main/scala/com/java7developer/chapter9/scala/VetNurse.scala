  import scala.actors._
  
  class VetNurse extends Actor {
    def act() {
    }
  }