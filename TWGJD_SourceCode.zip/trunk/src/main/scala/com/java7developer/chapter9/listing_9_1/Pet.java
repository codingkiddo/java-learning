package com.java7developer.chapter9.listing_9_1;

public abstract class Pet {

	protected final String name;
	
	public Pet(String name_) {
		name = name_;
	}
	
}
