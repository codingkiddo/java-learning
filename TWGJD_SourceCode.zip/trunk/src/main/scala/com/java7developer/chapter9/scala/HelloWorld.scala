object HelloWorld {

  def main(args : Array[String]) {
    val hello = "Hello World!"
    println(hello)
  }
}
