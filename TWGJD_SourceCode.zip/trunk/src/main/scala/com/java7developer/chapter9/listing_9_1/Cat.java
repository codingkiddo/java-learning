package com.java7developer.chapter9.listing_9_1;

public class Cat extends Pet implements Chipped {

	public Cat(String name_) {
		super(name_);
	}

	public String getName() {
		return name;
	}

}
