package com.java7developer.chapter9.listing_9_1;

/**
 * 
 * @author boxcat
 *
 */
public interface Chipped {
	String getName(); // Reads the animal's name from the chip
}
