trait Chipped {
  var chipName : String
  def getName = chipName
}
