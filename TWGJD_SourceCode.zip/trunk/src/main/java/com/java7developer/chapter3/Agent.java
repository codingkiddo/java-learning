package com.java7developer.chapter3;

/**
 * Agent class, used by many listings in CH03
 */
public class Agent {

  private String type;

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

}
