package com.java7developer.chapter3;

import java.util.List;

/**
 * Code for listing 3_1 - AgentFinder interface
 */
public interface AgentFinder {

  public List<Agent> findAllAgents();

}
