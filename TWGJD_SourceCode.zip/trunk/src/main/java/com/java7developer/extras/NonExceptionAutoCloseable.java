package com.java7developer.extras;

public interface NonExceptionAutoCloseable extends AutoCloseable {
  void close();
}
