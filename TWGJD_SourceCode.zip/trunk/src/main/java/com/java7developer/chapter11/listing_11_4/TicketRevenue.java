package com.java7developer.chapter11.listing_11_4;

import java.math.BigDecimal;

// This class is provided so that the Listing_11_4 test class compiles
public class TicketRevenue {

  public BigDecimal estimateTotalRevenue(int numberOfTicketsSold) {
    return BigDecimal.ZERO;
  }
}