package com.java7developer.chapter11.listing_11_18;

import java.math.BigDecimal;

// This is just an initial implementation that ensures that 
// The test class for Listing_11_18 compiles.
public interface Price {
  BigDecimal getInitialPrice();
}
