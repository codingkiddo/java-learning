package com.java7developer.chapter11.listing_11_11;

import java.math.BigDecimal;

public interface Price {
  BigDecimal getInitialPrice();
}
