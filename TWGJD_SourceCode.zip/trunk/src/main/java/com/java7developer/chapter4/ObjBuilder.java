package com.java7developer.chapter4;

public interface ObjBuilder<T> {
  T build();
}