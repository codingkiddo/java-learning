Scratchpad2 pad = new Scratchpad2()
println(pad.doStuff())

class Scratchpad2
{
  def private x
  Integer doStuff()
  { 
    x = 1
    def y; def String z = "Hello";
    x = 3
  }
}