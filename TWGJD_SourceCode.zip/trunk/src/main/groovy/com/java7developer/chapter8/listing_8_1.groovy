Scratchpad pad = new Scratchpad()
println(pad.doStuff())

public class Scratchpad
{
  public Integer doStuff()
  { 
    def x = 1
    def y; def String z = "Hello";
    x = 3
  }
}