package com.java7developer.chapter13

/*
class PlayerCharacterController {
  List playerCharacters
  def list = {
    playerCharacters = PlayerCharacter.list()
  }
}
*/

/*
 * Comment out the PlayerCharacterController above and uncomment this section 
 * to use Grails scaffolding
 */
class PlayerCharacterController {
    def scaffold = PlayerCharacter
}
