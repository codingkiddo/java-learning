(defn const-fun-arity1
  ([] 1)
  ([x] 1)
  ([x & more] 1)
)
