package com.codingkiddo.obg.streams;

import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.*;
import java.util.stream.*;

import static java.util.stream.Collectors.*;

/**
 * Open Banking / Keycloak-style domain examples using Java 8 Streams.
 *
 * Run:
 *   mvn -q -DskipTests package
 *   java -jar target/open-banking-streams-examples-1.0.0-jar-with-dependencies.jar
 */
public class StreamOpenBankingPlayground {

    // ===== Domain =====
    enum Scope { AIS, PIS }

    static class Account {
        final String id;
        final String region; // e.g., "IN", "EU", "US"
        final String ownerUserId;
        Account(String id, String region, String ownerUserId) {
            this.id = id; this.region = region; this.ownerUserId = ownerUserId;
        }
        public String toString(){ return "Acc("+id+","+region+")"; }
    }

    static class Transaction {
        final String id;
        final String accountId;
        final String merchant;
        final BigDecimal amount; // positive = debit, negative = credit (refund)
        final LocalDateTime ts;
        final String mcc; // merchant category code
        Transaction(String id, String accountId, String merchant, BigDecimal amount, LocalDateTime ts, String mcc) {
            this.id = id; this.accountId = accountId; this.merchant = merchant; this.amount = amount; this.ts = ts; this.mcc = mcc;
        }
        public String toString(){ return "Txn("+id+","+accountId+","+merchant+","+amount+")"; }
    }

    static class Consent {
        final String id;
        final String userId;          // PSU (resource owner)
        final String tppClientId;     // OAuth2 client
        final EnumSet<Scope> scopes;  // AIS/PIS
        final Set<String> accountIds; // accounts granted
        final Instant expiresAt;
        Consent(String id, String userId, String tppClientId, EnumSet<Scope> scopes, Set<String> accountIds, Instant expiresAt) {
            this.id = id; this.userId = userId; this.tppClientId = tppClientId; this.scopes = scopes; this.accountIds = accountIds; this.expiresAt = expiresAt;
        }
        boolean isActive(Instant now){ return expiresAt.isAfter(now); }
    }

    static class TPPClient {
        final String id;
        final String name;
        final Set<String> allowedScopes; // configured in Keycloak client
        TPPClient(String id, String name, Set<String> allowedScopes) {
            this.id = id; this.name = name; this.allowedScopes = allowedScopes;
        }
    }

    static class Token {
        final String subject; // userId
        final String clientId;
        final Set<String> scopeClaims;   // e.g., ["ais","openid"]
        final Set<String> accountClaims; // e.g., ["A1","A2"]
        Token(String subject, String clientId, Set<String> scopeClaims, Set<String> accountClaims) {
            this.subject = subject; this.clientId = clientId; this.scopeClaims = scopeClaims; this.accountClaims = accountClaims;
        }
    }

    // ===== Utilities =====
    @SafeVarargs
    static <T> Predicate<T> distinctByKeys(Function<? super T, ?>... keyExtractors) {
        Set<List<?>> seen = ConcurrentHashMap.newKeySet();
        return t -> seen.add(Arrays.stream(keyExtractors).map(f -> f.apply(t)).collect(toList()));
    }

    static class Pair<A,B> {
        final A a; final B b;
        Pair(A a, B b){ this.a=a; this.b=b; }
        public String toString(){ return "("+a+","+b+")"; }
    }

    // ===== Sample data =====
    static class Data {
        static List<Account> accounts() {
            return Arrays.asList(
                new Account("A1","IN","U1"),
                new Account("A2","IN","U1"),
                new Account("A3","EU","U2"),
                new Account("A4","US","U3")
            );
        }
        static List<Transaction> txns() {
            LocalDateTime base = LocalDateTime.now().minusDays(10);
            return Arrays.asList(
                new Transaction("T1","A1","AMAZON", new BigDecimal("1200.00"), base.plusHours(1), "5311"),
                new Transaction("T2","A1","UBER",   new BigDecimal("350.00"),  base.plusHours(2), "4121"),
                new Transaction("T3","A2","SWIGGY", new BigDecimal("650.00"),  base.plusHours(3), "5814"),
                new Transaction("T4","A3","AMAZON", new BigDecimal("220.00"),  base.plusHours(4), "5311"),
                new Transaction("T5","A1","UBER",   new BigDecimal("410.00"),  base.plusHours(5), "4121"),
                new Transaction("T6","A1","UBER",   new BigDecimal("405.00"),  base.plusHours(5).plusMinutes(5), "4121"), // rapid repeat
                new Transaction("T7","A2","CRED",   new BigDecimal("5000.00"), base.plusDays(1), "6012"),
                new Transaction("T8","A4","WALMART",new BigDecimal("130.00"),  base.plusDays(2), "5411")
            );
        }
        static List<Consent> consents() {
            return Arrays.asList(
                new Consent("C1","U1","TPP1", EnumSet.of(Scope.AIS), new HashSet<>(Arrays.asList("A1","A2")), Instant.now().plus(Duration.ofDays(30))),
                new Consent("C2","U2","TPP2", EnumSet.of(Scope.AIS, Scope.PIS), new HashSet<>(Arrays.asList("A3")), Instant.now().minus(Duration.ofDays(1))) // expired
            );
        }
        static List<TPPClient> clients() {
            return Arrays.asList(
                new TPPClient("TPP1","FinDash", new HashSet<>(Arrays.asList("openid","profile","ais"))),
                new TPPClient("TPP2","PayInit", new HashSet<>(Arrays.asList("openid","pis")))
            );
        }
        static List<Token> tokens() {
            return Arrays.asList(
                new Token("U1","TPP1", new HashSet<>(Arrays.asList("openid","ais")), new HashSet<>(Arrays.asList("A1","A2"))),
                new Token("U2","TPP2", new HashSet<>(Arrays.asList("openid","pis")), new HashSet<>(Arrays.asList("A3")))
            );
        }
    }

    public static void main(String[] args) {
        System.out.println("== Open Banking Streams ==");
        exampleConsentAwareTxnFilter();
        exampleAccessibleAccountsPerClient();
        exampleMonthlyStatementAggregation();
        exampleTopMerchantsByRegion();
        exampleDuplicatePaymentDetection();
        exampleVelocityWindowFraudHeuristic();
        exampleScopeMismatchAudit();
        System.out.println("== Done ==");
    }

    /**
     * 1) Consent-aware transaction filter (AIS scope, active, account bound)
     */
    static void exampleConsentAwareTxnFilter() {
        List<Transaction> txns = Data.txns();
        List<Consent> consents = Data.consents();
        Instant now = Instant.now();

        Set<String> allowedAccounts = consents.stream()
            .filter(c -> c.isActive(now))
            .filter(c -> c.scopes.contains(Scope.AIS))
            .flatMap(c -> c.accountIds.stream())
            .collect(toSet());

        List<Transaction> visible = txns.stream()
            .filter(t -> allowedAccounts.contains(t.accountId))
            .collect(toList());

        System.out.println("[Consent/AIS] visible txns: " + visible);
    }

    /**
     * 2) Join clients + consents => "accessible accounts per client" view
     */
    static void exampleAccessibleAccountsPerClient() {
        List<TPPClient> clients = Data.clients();
        List<Consent> consents = Data.consents();
        Instant now = Instant.now();

        Map<String, Set<String>> accsByClient = consents.stream()
            .filter(c -> c.isActive(now))
            .collect(groupingBy(c -> c.tppClientId,
                mapping(c -> c.accountIds, reducing(new HashSet<String>(), (a,b) -> { a.addAll(b); return a; }))));

        Map<String, Set<String>> result = clients.stream()
            .filter(c -> c.allowedScopes.contains("ais"))
            .collect(toMap(c -> c.name, c -> accsByClient.getOrDefault(c.id, Collections.emptySet())));

        System.out.println("[Client->Accounts] " + result);
    }

    /**
     * 3) Statement aggregation: per (account, month) -> total, count, avg
     */
    static void exampleMonthlyStatementAggregation() {
        List<Transaction> txns = Data.txns();

        Map<String, IntSummaryStatistics> stats = txns.stream()
            .collect(groupingBy(t -> t.accountId + "|" + YearMonth.from(t.ts),
                collectingAndThen(
                    mapping(t -> t.amount.intValue(), toList()),
                    l -> l.stream().mapToInt(Integer::intValue).summaryStatistics()
                )));

        stats.entrySet().stream().limit(3).forEach(e ->
            System.out.println("[Statement] " + e.getKey() + " -> sum=" + e.getValue().getSum() + " avg=" + e.getValue().getAverage())
        );
    }

    /**
     * 4) Top merchants by region (join txns->accounts, then group)
     */
    static void exampleTopMerchantsByRegion() {
        List<Transaction> txns = Data.txns();
        Map<String, Account> accIndex = Data.accounts().stream().collect(toMap(a -> a.id, a -> a));

        Map<String, List<Pair<String, Integer>>> topByRegion =
            txns.stream()
                .map(t -> new Pair<>(accIndex.get(t.accountId).region, t))
                .collect(groupingBy(p -> p.a,
                    collectingAndThen(toList(), list -> {
                        Map<String, Integer> sumByMerchant = list.stream()
                            .collect(groupingBy(p -> p.b.merchant, summingInt(p -> p.b.amount.intValue())));
                        return sumByMerchant.entrySet().stream()
                            .sorted(Map.Entry.<String,Integer>comparingByValue().reversed())
                            .limit(2)
                            .map(e -> new Pair<>(e.getKey(), e.getValue()))
                            .collect(toList());
                    })));
        System.out.println("[Top merchants by region] " + topByRegion);
    }

    /**
     * 5) Duplicate payment detection using distinctByKeys on (accountId, amount, minute)
     */
    static void exampleDuplicatePaymentDetection() {
        List<Transaction> txns = new ArrayList<>(Data.txns());
        // Simulate a duplicate/near-duplicate entry
        Transaction dup = new Transaction("T9","A1","UBER", new BigDecimal("350.00"), txns.get(1).ts.plusSeconds(30), "4121");
        txns.add(dup);

        List<Transaction> deduped = txns.stream()
            .filter(distinctByKeys(
                t -> t.accountId,
                t -> t.amount,
                t -> t.ts.withSecond(0).withNano(0) // bucket to minute
            ))
            .collect(toList());

        System.out.println("[Deduped size] " + deduped.size() + " (from " + txns.size() + ")");
    }

    /**
     * 6) Velocity heuristic: flag bursts (>2 ride-hailing spends in 10 minutes)
     */
    static void exampleVelocityWindowFraudHeuristic() {
        List<Transaction> txns = Data.txns().stream()
            .filter(t -> "4121".equals(t.mcc)) // ride-hailing
            .sorted(Comparator.comparing(t -> t.ts))
            .collect(toList());

        // sliding window count per account
        Map<String, Boolean> flagged = txns.stream()
            .collect(groupingBy(t -> t.accountId,
                collectingAndThen(toList(), list -> {
                    list.sort(Comparator.comparing(t -> t.ts));
                    for (int i=0; i<list.size(); i++) {
                        LocalDateTime start = list.get(i).ts;
                        long count = list.stream()
                            .skip(i)
                            .takeWhile(t -> Duration.between(start, t.ts).toMinutes() <= 10)
                            .count();
                        if (count > 2) return true;
                    }
                    return false;
                }))
            );

        System.out.println("[Velocity flagged] " + flagged);
    }

    /**
     * 7) Scope mismatch audit: token scope vs client allowedScopes vs consent scopes
     */
    static void exampleScopeMismatchAudit() {
        List<Token> tokens = Data.tokens();
        List<TPPClient> clients = Data.clients();
        Map<String, TPPClient> clientIndex = clients.stream().collect(toMap(c -> c.id, c -> c));
        List<Consent> consents = Data.consents();
        Instant now = Instant.now();

        Map<String, Set<String>> consentScopesByClient = consents.stream()
            .filter(c -> c.isActive(now))
            .collect(groupingBy(c -> c.tppClientId,
                mapping(c -> c.scopes.stream().map(Enum::name).map(String::toLowerCase).collect(toSet()),
                        reducing(new HashSet<String>(), (a,b)->{a.addAll(b); return a;}))));

        List<String> mismatches = tokens.stream()
            .flatMap(tok -> {
                TPPClient client = clientIndex.get(tok.clientId);
                Set<String> clientScopes = client.allowedScopes;
                Set<String> consentScopes = consentScopesByClient.getOrDefault(tok.clientId, Collections.emptySet());

                boolean ok = tok.scopeClaims.stream().allMatch(clientScopes::contains) &&
                             tok.scopeClaims.stream().allMatch(consentScopes::contains);

                return ok ? Stream.empty()
                          : Stream.of("Token for client "+client.name+" has mismatched scopes: " + tok.scopeClaims);
            })
            .collect(toList());

        System.out.println("[Scope mismatches] " + mismatches);
    }
}
