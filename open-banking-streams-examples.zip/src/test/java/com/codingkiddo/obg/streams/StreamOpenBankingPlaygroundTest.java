package com.codingkiddo.obg.streams;

import org.junit.Test;

public class StreamOpenBankingPlaygroundTest {
    @Test
    public void runsMain() {
        StreamOpenBankingPlayground.main(new String[0]);
    }
}
