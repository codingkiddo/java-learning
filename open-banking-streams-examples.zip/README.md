# Open Banking Streams — Java 8 Complex Examples

Domain-tailored stream patterns for Open Banking / Keycloak-style setups:
- Consent-aware AIS filtering of transactions
- Join clients + consents to compute accessible accounts per client
- Statement aggregation: (account, month) -> sum/count/avg
- Top merchants by region (txn->account join)
- Duplicate payment detection with `distinctByKeys`
- Velocity window heuristic for fraud (count events in 10-minute windows)
- Scope mismatch audit across token vs client vs consents

## Run
```bash
mvn -q -DskipTests package
java -jar target/open-banking-streams-examples-1.0.0-jar-with-dependencies.jar
```

## Test
```bash
mvn -q test
```
